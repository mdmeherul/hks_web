===== Xoha Pro =====

Xoha Pro plugin adds advanced features for Xoha theme.


== Changelog ==

= 1.0.1 =

    * Fixed: Elementor shortcodes loading elements

= 1.0.0 =

    * First release!