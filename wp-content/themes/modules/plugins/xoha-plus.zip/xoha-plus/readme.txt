===== Xoha Plus =====

Xoha Plus plugin adds additonal features for Xoha theme.


== Changelog ==

= 1.0.0 =

    * First release!